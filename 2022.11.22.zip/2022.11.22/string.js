function kiir(eredmeny) {
    document.getElementById("eredmeny").innerHTML = elements + "<br>"

}
var szoveg = "Maci dalol a mezőn és nézi az eget."
var szoveg2 = "Bakkecske baktat"
var szamsor ="1:2:3:4:5"

function csinald() {
    kiir(szoveg.length)
    kiir(szoveg.substring(5,15))
    kiir(szoveg.substring(5))
    kiir(szoveg.substring(-5,-15))
    kiir(szoveg.replace("Maci","Macika"))
    kiir(szoveg.concat("buborek","text"))
    kiir(szoveg.charAt(8))
    kiir(szoveg.split(" "))
    kiir(szoveg.toLowerCase())
    kiir(szoveg.toUpperCase())
    kiir(szoveg.trim())

    kiir(szoveg.replace("b", "c"))

    szamlista = szamsor.split()
    osszeg = 0
    szamlista.forEach(c => {
        osszeg += c
    });

    kiir(osszeg)

    kiir(szoveg2.replaceAll("b", "B" && "c", "C"))


}
